# Sales-Dashboard-Using-Power-BI

* In this project, i have made a intractive Power BI Sales Dashboard on Global_super_store sales data and find some insights from the data. In order to building the dashboard the ETL process was done as per the requirements, Power query was used to clean and transform the data and DAX was used for creating the culculated measures and culculated column.
* Once done with the culculations, i have made visualizations and create report using cards, charts, slicer etc.
* Which help to easy understanding of the end-user and give meaningful insights.


## Tools and Technology used-
#### 1. Microsoft Power BI
#### 2. MS Excel


## Data Source used- 
* Kaggle- https://www.kaggle.com/datasets/tahir1413/global-superstore-2016
